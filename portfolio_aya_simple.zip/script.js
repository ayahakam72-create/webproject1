document.getElementById('year').textContent=new Date().getFullYear();
function handleContact(e){e.preventDefault();
var name=e.target.name.value.trim(),msg=e.target.message.value.trim(),
formMsg=document.getElementById('formMsg');
if(!name||!msg){formMsg.style.color='crimson';formMsg.textContent='من فضلك املأ كل الحقول.';return;}
formMsg.style.color='green';formMsg.textContent='تم الإرسال! (نموذج تجريبي)';
e.target.reset();setTimeout(()=>{formMsg.textContent='';},3000);
}